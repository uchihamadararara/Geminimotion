// Procedural 120 BPM soundtrack -> public/music.wav (no downloads, no licences)
import fs from 'fs';

const SR = 44100;
const DUR = 54.8;
const N = Math.ceil(SR * DUR);
const buf = new Float32Array(N);
const beat = 0.5; // 120 BPM
let seed = 1234;
const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296) * 2 - 1;

const add = (t0, len, fn) => {
  const s = Math.floor(t0 * SR);
  for (let i = 0; i < len * SR && s + i < N; i++) buf[s + i] += fn(i / SR);
};

const kick = (t) => {
  let ph = 0;
  add(t, 0.35, (x) => {
    ph += (2 * Math.PI * (46 + 120 * Math.exp(-x * 30))) / SR;
    return Math.sin(ph) * Math.exp(-x * 8) * 0.9;
  });
};
const hat = (t, a = 0.16) => {
  let prev = 0;
  add(t, 0.06, (x) => {
    const n = rnd();
    const hp = n - prev;
    prev = n;
    return hp * Math.exp(-x * 90) * a;
  });
};
const clap = (t) => {
  let lp = 0;
  add(t, 0.22, (x) => {
    lp += (rnd() - lp) * 0.45;
    const env = Math.exp(-x * 24) + 0.6 * Math.exp(-Math.max(0, x - 0.012) * 60);
    return lp * env * 0.3;
  });
};
const bass = (t, hz) =>
  add(t, 0.3, (x) => (Math.sin(2 * Math.PI * hz * x) + 0.3 * Math.sin(4 * Math.PI * hz * x)) * Math.exp(-x * 7) * 0.28);
const pluck = (t, hz, a = 0.11) =>
  add(t, 0.4, (x) => {
    const ph = (x * hz) % 1;
    return (Math.abs(ph * 4 - 2) - 1) * Math.exp(-x * 13) * a;
  });
const boom = (t) => {
  add(t, 0.8, (x) => Math.sin(2 * Math.PI * (55 - 20 * x) * x) * Math.exp(-x * 5) * 0.55);
  let lp = 0;
  add(t, 0.35, (x) => {
    lp += (rnd() - lp) * 0.2;
    return lp * Math.exp(-x * 12) * 0.5;
  });
};
const riser = (t0, len) => {
  let ph = 0;
  add(t0, len, (x) => {
    const k = x / len;
    ph += (2 * Math.PI * (200 + 1800 * k * k)) / SR;
    return (Math.sin(ph) * 0.5 + rnd() * 0.25) * k * k * 0.25;
  });
};

const scale = [220, 261.63, 329.63, 392, 440];
const beats = Math.floor(DUR / beat);
for (let i = 0; i < beats; i++) {
  const t = i * beat;
  if (t >= 1.0 && t < 54) kick(t);
  if (t >= 2.5) {
    hat(t + beat / 2);
    if (i % 2 === 0) hat(t, 0.07);
  }
  if (t >= 5 && i % 2 === 1) clap(t);
  if (t >= 5) bass(t + beat / 2, [55, 55, 65.4, 49][Math.floor(i / 8) % 4]);
  if (t >= 10 && t < 53) {
    for (let k = 0; k < 2; k++) {
      const idx = (i * 2 + k) * 3 + ((i * 2 + k) >> 2);
      pluck(t + (k * beat) / 2, scale[idx % 5] * (i % 16 >= 8 ? 2 : 1));
    }
  }
}
for (let s = 0; s < 11; s++) boom(s * 5);
riser(47.5, 2.5);
riser(28, 2);

// fade out + normalise
let peak = 0;
for (let i = 0; i < N; i++) {
  const fade = Math.min(1, (N - i) / (SR * 0.8));
  buf[i] *= fade;
  peak = Math.max(peak, Math.abs(buf[i]));
}
const g = 0.9 / (peak || 1);
const out = Buffer.alloc(44 + N * 2);
out.write('RIFF', 0); out.writeUInt32LE(36 + N * 2, 4); out.write('WAVE', 8);
out.write('fmt ', 12); out.writeUInt32LE(16, 16); out.writeUInt16LE(1, 20); out.writeUInt16LE(1, 22);
out.writeUInt32LE(SR, 24); out.writeUInt32LE(SR * 2, 28); out.writeUInt16LE(2, 32); out.writeUInt16LE(16, 34);
out.write('data', 36); out.writeUInt32LE(N * 2, 40);
for (let i = 0; i < N; i++) out.writeInt16LE(Math.max(-32767, Math.min(32767, Math.round(buf[i] * g * 32767))), 44 + i * 2);
fs.mkdirSync('public', {recursive: true});
fs.writeFileSync('public/music.wav', out);
console.log('public/music.wav written');
